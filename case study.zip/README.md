# Campus Library Lending System - SOLID Case Study

A small C++17 console application that demonstrates the five SOLID principles through a campus library borrowing and return workflow.

## Features

- View the sample book catalog and available copies.
- Borrow a book after checking the member and stock.
- Return a loan and calculate an overdue fee.
- View a member's loan history.
- Choose interchangeable late-fee policies and notification channels.
- Run automated tests without third-party test libraries.
- Run a demo that uses the added simulated push-notification channel.

## Project structure

```text
include/solid/library.hpp   Domain types, interfaces, policies, repositories, service
src/library.cpp             Implementations of policies, service and repositories
src/main.cpp                Console interface and composition root
tests/solid_tests.cpp       Assertions for core behaviour and interchangeable implementations
docs/class-diagram.mmd      Mermaid class relationship diagram
CMakeLists.txt              CMake build configuration
```

## Build with g++ (Windows MinGW, Linux, or macOS)

From the project root:

```bash
g++ -std=c++17 -Wall -Wextra -pedantic -Iinclude src/library.cpp src/main.cpp -o library_app
```

Run:

```bash
./library_app
```

On Windows Command Prompt, run `library_app.exe` after compiling with an appropriately configured MinGW g++ compiler.

## Build and run tests with g++

```bash
g++ -std=c++17 -Wall -Wextra -pedantic -Iinclude src/library.cpp tests/solid_tests.cpp -o solid_tests
./solid_tests
```

Expected output:

```text
All SOLID library tests passed.
```

## Build with CMake

```bash
cmake -S . -B build
cmake --build build
ctest --test-dir build --output-on-failure
```

## Demonstrate the extension

Run:

```bash
./library_app --demo
```

The demo uses `PushNotificationChannel`, a new implementation of `INotificationChannel`. It prints a simulated push message. It does **not** connect to Firebase, APNs, or a real mobile application. The important design point is that `LoanService` does not need to change when a new notification implementation is added.

To start the interactive application with the simulated push channel:

```bash
./library_app --push
```

## Sample usage

The program starts with these sample records:

- Books: `B001`, `B002`, `B003`
- Members: `M001`, `M002`

Example interactive sequence:

1. Choose `1` to view books.
2. Choose `2`, enter member `M001`, book `B001`, and due date `2026-11-06`.
3. Note the generated loan ID (for example, `LN0001`).
4. Choose `3`, enter the loan ID and overdue days such as `2`.
5. Choose `4` and enter `M001` to view loan history.

The demo uses a fixed sample late-fee rate of Rs. 2.00 per overdue day. The interactive program asks the operator to enter overdue days; a production system should calculate this from validated dates and apply institutional rules.

## Where SOLID appears

- **SRP:** `InMemoryBookRepository` handles book storage, `InMemoryMemberRepository` handles member lookup, notification channels handle message delivery, and `LoanService` coordinates loan use cases.
- **OCP:** `ILateFeePolicy` allows another fee rule to be added; `INotificationChannel` allows another notification channel to be added. `PushNotificationChannel` is the demonstrated extension.
- **LSP:** `FlatDailyFeePolicy` and `CappedDailyFeePolicy` both obey the `ILateFeePolicy` contract. Console and simulated-push channels can both be used through `INotificationChannel`.
- **ISP:** The storage contracts are split into focused interfaces: `IBookReader`, `IBookStockManager`, `IMemberReader`, `ILoanReader`, and `ILoanWriter`.
- **DIP:** `LoanService` receives references to interfaces through its constructor and does not create concrete repositories, policies, or notification channels.

## Important scope and limitations

This is an in-memory teaching prototype. Data is reset when the process exits. The push notification is simulated. It does not include authentication, persistent database storage, concurrency control, real calendar-based overdue calculation, or production mobile integration. SOLID supports accommodating changing requirements; by itself it does not prove high throughput or performance scalability under heavy user load.

## Contributors

- Student 1: [Full name] - [Registration number] - [Actual contribution]
- Student 2 (if applicable): [Full name] - [Registration number] - [Actual contribution]

Update this section with the actual contributor details before publishing the repository.
