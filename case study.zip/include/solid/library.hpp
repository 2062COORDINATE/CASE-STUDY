#ifndef SOLID_LIBRARY_HPP
#define SOLID_LIBRARY_HPP

#include <iosfwd>
#include <map>
#include <optional>
#include <string>
#include <vector>

namespace campus_library {

// Domain objects contain data only; application rules live in services/policies.
struct Book {
    std::string id;
    std::string title;
    int availableCopies{0};
};

struct Member {
    std::string id;
    std::string name;
};

struct Loan {
    std::string id;
    std::string bookId;
    std::string memberId;
    std::string dueDate;
    bool returned{false};
    int daysOverdue{0};
};

// Narrow interfaces: each client can depend only on the capability it needs.
class IBookReader {
public:
    virtual ~IBookReader() = default;
    virtual std::optional<Book> findBook(const std::string& bookId) const = 0;
    virtual std::vector<Book> listBooks() const = 0;
};

class IBookStockManager {
public:
    virtual ~IBookStockManager() = default;
    virtual bool changeAvailableCopies(const std::string& bookId, int change) = 0;
};

class IMemberReader {
public:
    virtual ~IMemberReader() = default;
    virtual std::optional<Member> findMember(const std::string& memberId) const = 0;
};

class ILoanReader {
public:
    virtual ~ILoanReader() = default;
    virtual std::optional<Loan> findLoan(const std::string& loanId) const = 0;
    virtual std::vector<Loan> listLoansForMember(const std::string& memberId) const = 0;
};

class ILoanWriter {
public:
    virtual ~ILoanWriter() = default;
    virtual void saveLoan(const Loan& loan) = 0;
    virtual bool updateLoan(const Loan& loan) = 0;
};

// Strategy abstraction for alternative late-fee rules.
class ILateFeePolicy {
public:
    virtual ~ILateFeePolicy() = default;
    // Contract: return a non-negative fee; zero or negative overdue days mean no fee.
    virtual double calculate(int daysOverdue) const = 0;
};

class FlatDailyFeePolicy final : public ILateFeePolicy {
public:
    explicit FlatDailyFeePolicy(double dailyRate);
    double calculate(int daysOverdue) const override;
private:
    double dailyRate_;
};

class CappedDailyFeePolicy final : public ILateFeePolicy {
public:
    CappedDailyFeePolicy(double dailyRate, double maximumFee);
    double calculate(int daysOverdue) const override;
private:
    double dailyRate_;
    double maximumFee_;
};

// A client of this interface does not need to know whether a message is printed,
// emailed, or sent to a mobile push provider.
class INotificationChannel {
public:
    virtual ~INotificationChannel() = default;
    virtual void send(const std::string& message) = 0;
};

class ConsoleNotificationChannel final : public INotificationChannel {
public:
    explicit ConsoleNotificationChannel(std::ostream& output);
    void send(const std::string& message) override;
private:
    std::ostream& output_;
};

// Demonstration extension. This simulates a push notification; it does not call
// a real mobile push service or require credentials/network access.
class PushNotificationChannel final : public INotificationChannel {
public:
    explicit PushNotificationChannel(std::ostream& output);
    void send(const std::string& message) override;
private:
    std::ostream& output_;
};

// Application service: coordinates borrowing/returning while depending on
// abstractions rather than concrete repositories, fee rules, or channels.
class LoanService {
public:
    LoanService(const IBookReader& bookReader,
                IBookStockManager& stockManager,
                const IMemberReader& memberReader,
                const ILoanReader& loanReader,
                ILoanWriter& loanWriter,
                const ILateFeePolicy& lateFeePolicy,
                INotificationChannel& notificationChannel);

    std::string borrowBook(const std::string& memberId,
                           const std::string& bookId,
                           const std::string& dueDate);
    double returnBook(const std::string& loanId, int daysOverdue);
    std::vector<Loan> loansForMember(const std::string& memberId) const;

private:
    const IBookReader& bookReader_;
    IBookStockManager& stockManager_;
    const IMemberReader& memberReader_;
    const ILoanReader& loanReader_;
    ILoanWriter& loanWriter_;
    const ILateFeePolicy& lateFeePolicy_;
    INotificationChannel& notificationChannel_;
    unsigned int nextLoanNumber_{1};
};

// In-memory adapters keep this sample self-contained. They can be replaced by
// database/file-backed adapters without changing LoanService.
class InMemoryBookRepository final : public IBookReader, public IBookStockManager {
public:
    explicit InMemoryBookRepository(const std::vector<Book>& initialBooks);
    std::optional<Book> findBook(const std::string& bookId) const override;
    std::vector<Book> listBooks() const override;
    bool changeAvailableCopies(const std::string& bookId, int change) override;
private:
    std::map<std::string, Book> books_;
};

class InMemoryMemberRepository final : public IMemberReader {
public:
    explicit InMemoryMemberRepository(const std::vector<Member>& initialMembers);
    std::optional<Member> findMember(const std::string& memberId) const override;
private:
    std::map<std::string, Member> members_;
};

class InMemoryLoanRepository final : public ILoanReader, public ILoanWriter {
public:
    std::optional<Loan> findLoan(const std::string& loanId) const override;
    std::vector<Loan> listLoansForMember(const std::string& memberId) const override;
    void saveLoan(const Loan& loan) override;
    bool updateLoan(const Loan& loan) override;
private:
    std::map<std::string, Loan> loans_;
};

} // namespace campus_library

#endif // SOLID_LIBRARY_HPP
