#include "solid/library.hpp"

#include <cassert>
#include <iostream>
#include <sstream>
#include <stdexcept>
#include <string>
#include <vector>

using namespace campus_library;

namespace {

class RecordingNotificationChannel final : public INotificationChannel {
public:
    void send(const std::string& message) override { messages.push_back(message); }
    std::vector<std::string> messages;
};

void testBorrowReturnAndInventory() {
    InMemoryBookRepository books({{"B1", "Test Book", 1}});
    InMemoryMemberRepository members({{"M1", "Test Member"}});
    InMemoryLoanRepository loans;
    FlatDailyFeePolicy feePolicy(2.50);
    RecordingNotificationChannel notifications;
    LoanService service(books, books, members, loans, loans, feePolicy, notifications);

    const auto loanId = service.borrowBook("M1", "B1", "2026-11-10");
    assert(books.findBook("B1")->availableCopies == 0);
    assert(loans.findLoan(loanId).has_value());
    const double fee = service.returnBook(loanId, 2);
    assert(fee == 5.0);
    assert(books.findBook("B1")->availableCopies == 1);
    assert(loans.findLoan(loanId)->returned);
    assert(notifications.messages.size() == 2);
}

void testOutOfStockIsRejected() {
    InMemoryBookRepository books({{"B1", "Unavailable Book", 0}});
    InMemoryMemberRepository members({{"M1", "Test Member"}});
    InMemoryLoanRepository loans;
    FlatDailyFeePolicy feePolicy(1.0);
    RecordingNotificationChannel notifications;
    LoanService service(books, books, members, loans, loans, feePolicy, notifications);

    bool rejected = false;
    try {
        service.borrowBook("M1", "B1", "2026-11-10");
    } catch (const std::runtime_error&) {
        rejected = true;
    }
    assert(rejected);
    assert(loans.listLoansForMember("M1").empty());
}

void verifyFeePolicyContract(const ILateFeePolicy& policy) {
    // LSP contract: all fee-policy implementations return non-negative values.
    assert(policy.calculate(-3) == 0.0);
    assert(policy.calculate(0) == 0.0);
    assert(policy.calculate(4) >= 0.0);
}

void testFeePoliciesAreInterchangeable() {
    FlatDailyFeePolicy flat(3.0);
    CappedDailyFeePolicy capped(3.0, 7.0);
    std::vector<const ILateFeePolicy*> policies{&flat, &capped};
    for (const auto* policy : policies) {
        verifyFeePolicyContract(*policy);
    }
    assert(flat.calculate(4) == 12.0);
    assert(capped.calculate(4) == 7.0);
}

void testNotificationImplementationsAreInterchangeable() {
    std::ostringstream consoleOutput;
    std::ostringstream pushOutput;
    ConsoleNotificationChannel console(consoleOutput);
    PushNotificationChannel push(pushOutput);
    INotificationChannel& consoleChannel = console;
    INotificationChannel& pushChannel = push;
    consoleChannel.send("hello");
    pushChannel.send("hello");
    assert(consoleOutput.str().find("CONSOLE NOTIFICATION") != std::string::npos);
    assert(pushOutput.str().find("PUSH NOTIFICATION") != std::string::npos);
}

} // namespace

int main() {
    testBorrowReturnAndInventory();
    testOutOfStockIsRejected();
    testFeePoliciesAreInterchangeable();
    testNotificationImplementationsAreInterchangeable();
    std::cout << "All SOLID library tests passed.\n";
    return 0;
}
