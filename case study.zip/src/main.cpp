#include "solid/library.hpp"

#include <iomanip>
#include <iostream>
#include <memory>
#include <sstream>
#include <string>

using namespace campus_library;

namespace {

void showBooks(const IBookReader& books) {
    std::cout << "\nBOOK CATALOG\n";
    for (const auto& book : books.listBooks()) {
        std::cout << "  " << book.id << " | " << book.title
                  << " | available copies: " << book.availableCopies << '\n';
    }
}

void showLoans(const std::vector<Loan>& loans) {
    if (loans.empty()) {
        std::cout << "No loans found for this member.\n";
        return;
    }
    for (const auto& loan : loans) {
        std::cout << "  " << loan.id << " | book: " << loan.bookId
                  << " | due: " << loan.dueDate
                  << " | status: " << (loan.returned ? "Returned" : "Active");
        if (loan.returned) {
            std::cout << " | overdue days: " << loan.daysOverdue;
        }
        std::cout << '\n';
    }
}

void runDemo(LoanService& service) {
    std::cout << "\nRunning a sample borrowing and return flow...\n";
    const std::string loanId = service.borrowBook("M001", "B001", "2026-11-06");
    const double fee = service.returnBook(loanId, 3);
    std::cout << "Demo completed. Loan ID: " << loanId
              << "; late fee: Rs. " << std::fixed << std::setprecision(2) << fee << "\n";
    std::cout << "Member M001 loan history:\n";
    showLoans(service.loansForMember("M001"));
}

} // namespace

int main(int argc, char* argv[]) {
    InMemoryBookRepository bookRepository({
        {"B001", "The C++ Programming Language", 3},
        {"B002", "Clean Code", 2},
        {"B003", "Design Patterns", 1}
    });
    InMemoryMemberRepository memberRepository({
        {"M001", "Aarav Sharma"},
        {"M002", "Maya Rai"}
    });
    InMemoryLoanRepository loanRepository;
    FlatDailyFeePolicy feePolicy(2.00);

    std::unique_ptr<INotificationChannel> notifier;
    const bool usePush = (argc > 1 && (std::string(argv[1]) == "--push" ||
                                      std::string(argv[1]) == "--demo"));
    if (usePush) {
        notifier = std::make_unique<PushNotificationChannel>(std::cout);
    } else {
        notifier = std::make_unique<ConsoleNotificationChannel>(std::cout);
    }

    LoanService loanService(bookRepository, bookRepository, memberRepository,
                            loanRepository, loanRepository, feePolicy, *notifier);

    if (argc > 1 && std::string(argv[1]) == "--demo") {
        try {
            runDemo(loanService);
        } catch (const std::exception& error) {
            std::cerr << "Demo error: " << error.what() << '\n';
            return 1;
        }
        return 0;
    }

    std::cout << "CAMPUS LIBRARY LENDING SYSTEM\n"
              << "Sample members: M001 (Aarav Sharma), M002 (Maya Rai)\n"
              << "Notification channel: " << (usePush ? "simulated push" : "console") << "\n";

    std::string choice;
    while (true) {
        std::cout << "\n1. View books\n2. Borrow a book\n3. Return a book\n"
                  << "4. View a member's loans\n0. Exit\nChoose: ";
        if (!std::getline(std::cin, choice)) {
            break;
        }

        try {
            if (choice == "0") {
                std::cout << "Goodbye.\n";
                break;
            } else if (choice == "1") {
                showBooks(bookRepository);
            } else if (choice == "2") {
                std::string memberId, bookId, dueDate;
                std::cout << "Member ID: ";
                std::getline(std::cin, memberId);
                std::cout << "Book ID: ";
                std::getline(std::cin, bookId);
                std::cout << "Due date (YYYY-MM-DD): ";
                std::getline(std::cin, dueDate);
                const auto loanId = loanService.borrowBook(memberId, bookId, dueDate);
                std::cout << "Book borrowed successfully. Loan ID: " << loanId << '\n';
            } else if (choice == "3") {
                std::string loanId, daysText;
                std::cout << "Loan ID: ";
                std::getline(std::cin, loanId);
                std::cout << "Days overdue (0 if on time): ";
                std::getline(std::cin, daysText);
                std::size_t used = 0;
                const int days = std::stoi(daysText, &used);
                if (used != daysText.size()) {
                    throw std::runtime_error("Enter a whole number of overdue days.");
                }
                const double fee = loanService.returnBook(loanId, days);
                std::cout << "Book returned. Late fee: Rs. "
                          << std::fixed << std::setprecision(2) << fee << '\n';
            } else if (choice == "4") {
                std::string memberId;
                std::cout << "Member ID: ";
                std::getline(std::cin, memberId);
                showLoans(loanService.loansForMember(memberId));
            } else {
                std::cout << "Choose one of the listed options.\n";
            }
        } catch (const std::exception& error) {
            std::cout << "Error: " << error.what() << '\n';
        }
    }
    return 0;
}
