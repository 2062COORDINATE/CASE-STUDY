#include "solid/library.hpp"

#include <algorithm>
#include <iomanip>
#include <ostream>
#include <sstream>
#include <stdexcept>

namespace campus_library {

FlatDailyFeePolicy::FlatDailyFeePolicy(double dailyRate) : dailyRate_(dailyRate) {
    if (dailyRate < 0.0) {
        throw std::invalid_argument("Daily fee rate cannot be negative.");
    }
}

double FlatDailyFeePolicy::calculate(int daysOverdue) const {
    return static_cast<double>(std::max(0, daysOverdue)) * dailyRate_;
}

CappedDailyFeePolicy::CappedDailyFeePolicy(double dailyRate, double maximumFee)
    : dailyRate_(dailyRate), maximumFee_(maximumFee) {
    if (dailyRate < 0.0 || maximumFee < 0.0) {
        throw std::invalid_argument("Fee rate and maximum fee cannot be negative.");
    }
}

double CappedDailyFeePolicy::calculate(int daysOverdue) const {
    const double uncapped = static_cast<double>(std::max(0, daysOverdue)) * dailyRate_;
    return std::min(uncapped, maximumFee_);
}

ConsoleNotificationChannel::ConsoleNotificationChannel(std::ostream& output)
    : output_(output) {}

void ConsoleNotificationChannel::send(const std::string& message) {
    output_ << "[CONSOLE NOTIFICATION] " << message << '\n';
}

PushNotificationChannel::PushNotificationChannel(std::ostream& output)
    : output_(output) {}

void PushNotificationChannel::send(const std::string& message) {
    output_ << "[PUSH NOTIFICATION - SIMULATED] " << message << '\n';
}

LoanService::LoanService(const IBookReader& bookReader,
                         IBookStockManager& stockManager,
                         const IMemberReader& memberReader,
                         const ILoanReader& loanReader,
                         ILoanWriter& loanWriter,
                         const ILateFeePolicy& lateFeePolicy,
                         INotificationChannel& notificationChannel)
    : bookReader_(bookReader),
      stockManager_(stockManager),
      memberReader_(memberReader),
      loanReader_(loanReader),
      loanWriter_(loanWriter),
      lateFeePolicy_(lateFeePolicy),
      notificationChannel_(notificationChannel) {}

std::string LoanService::borrowBook(const std::string& memberId,
                                    const std::string& bookId,
                                    const std::string& dueDate) {
    if (!memberReader_.findMember(memberId)) {
        throw std::runtime_error("Member ID was not found.");
    }
    const auto book = bookReader_.findBook(bookId);
    if (!book) {
        throw std::runtime_error("Book ID was not found.");
    }
    if (book->availableCopies <= 0) {
        throw std::runtime_error("No available copy of this book.");
    }
    if (dueDate.empty()) {
        throw std::runtime_error("Due date cannot be empty.");
    }
    if (!stockManager_.changeAvailableCopies(bookId, -1)) {
        throw std::runtime_error("Could not reserve a copy of this book.");
    }

    std::ostringstream id;
    id << "LN" << std::setw(4) << std::setfill('0') << nextLoanNumber_++;
    Loan loan{id.str(), bookId, memberId, dueDate, false, 0};
    loanWriter_.saveLoan(loan);

    notificationChannel_.send("Loan " + loan.id + " created for member " + memberId +
                              "; book: " + book->title + ". Due: " + dueDate + ".");
    return loan.id;
}

double LoanService::returnBook(const std::string& loanId, int daysOverdue) {
    auto loan = loanReader_.findLoan(loanId);
    if (!loan) {
        throw std::runtime_error("Loan ID was not found.");
    }
    if (loan->returned) {
        throw std::runtime_error("This loan has already been returned.");
    }
    if (!stockManager_.changeAvailableCopies(loan->bookId, 1)) {
        throw std::runtime_error("Could not update the book inventory.");
    }

    loan->returned = true;
    loan->daysOverdue = std::max(0, daysOverdue);
    if (!loanWriter_.updateLoan(*loan)) {
        // Restore the inventory if the loan record could not be updated.
        stockManager_.changeAvailableCopies(loan->bookId, -1);
        throw std::runtime_error("Could not update the loan record.");
    }

    const double fee = lateFeePolicy_.calculate(loan->daysOverdue);
    std::ostringstream message;
    message << "Loan " << loanId << " returned. Late fee: " << std::fixed
            << std::setprecision(2) << fee << ".";
    notificationChannel_.send(message.str());
    return fee;
}

std::vector<Loan> LoanService::loansForMember(const std::string& memberId) const {
    if (!memberReader_.findMember(memberId)) {
        throw std::runtime_error("Member ID was not found.");
    }
    return loanReader_.listLoansForMember(memberId);
}

InMemoryBookRepository::InMemoryBookRepository(const std::vector<Book>& initialBooks) {
    for (const auto& book : initialBooks) {
        books_.insert_or_assign(book.id, book);
    }
}

std::optional<Book> InMemoryBookRepository::findBook(const std::string& bookId) const {
    const auto it = books_.find(bookId);
    if (it == books_.end()) {
        return std::nullopt;
    }
    return it->second;
}

std::vector<Book> InMemoryBookRepository::listBooks() const {
    std::vector<Book> result;
    result.reserve(books_.size());
    for (const auto& entry : books_) {
        result.push_back(entry.second);
    }
    return result;
}

bool InMemoryBookRepository::changeAvailableCopies(const std::string& bookId, int change) {
    const auto it = books_.find(bookId);
    if (it == books_.end() || it->second.availableCopies + change < 0) {
        return false;
    }
    it->second.availableCopies += change;
    return true;
}

InMemoryMemberRepository::InMemoryMemberRepository(const std::vector<Member>& initialMembers) {
    for (const auto& member : initialMembers) {
        members_.insert_or_assign(member.id, member);
    }
}

std::optional<Member> InMemoryMemberRepository::findMember(const std::string& memberId) const {
    const auto it = members_.find(memberId);
    if (it == members_.end()) {
        return std::nullopt;
    }
    return it->second;
}

std::optional<Loan> InMemoryLoanRepository::findLoan(const std::string& loanId) const {
    const auto it = loans_.find(loanId);
    if (it == loans_.end()) {
        return std::nullopt;
    }
    return it->second;
}

std::vector<Loan> InMemoryLoanRepository::listLoansForMember(const std::string& memberId) const {
    std::vector<Loan> result;
    for (const auto& entry : loans_) {
        if (entry.second.memberId == memberId) {
            result.push_back(entry.second);
        }
    }
    return result;
}

void InMemoryLoanRepository::saveLoan(const Loan& loan) {
    if (loans_.find(loan.id) != loans_.end()) {
        throw std::runtime_error("Duplicate loan ID.");
    }
    loans_.emplace(loan.id, loan);
}

bool InMemoryLoanRepository::updateLoan(const Loan& loan) {
    const auto it = loans_.find(loan.id);
    if (it == loans_.end()) {
        return false;
    }
    it->second = loan;
    return true;
}

} // namespace campus_library
